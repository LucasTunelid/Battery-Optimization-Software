#Optimization algorithm

import numpy as np
from numpy.lib.arraysetops import unique
from numpy.ma.core import concatenate
import pandas as pd
from pandas.core.indexes.base import Index 






class Charge_Controller:
    #Define the charging controller used in the battery

    def __init__(self,Freq_Data, FCR_Price, FCR_Bid_Price, SoC_0, P_D_Max, P_C_Max, BESS_Cost, 
    Load_Curve,P_Cap, Cap_BESS, d_t, Cost_Peak, El_Price, Prev_Peak, Max_Load):
        """Defining the variables that the solver will take in before execution. Here Freq_Data is the frequency
        reading for one month, FCR_Price is the regulating price for FCR-N over the month, FCR_Bid_Price is the
        bid prices for each hour, SoC_0 is the inital state of charge of the BESS each month, BESS_Cost is the 
        cost of installing the battery, P_D_Max is the maximum discharge power in kW, P_C_Max is the maximum 
        charge power in kW that the BESS can handle. Load_Curve is the associated load curve of the plant, 
        P_Cap is the capacity of the grid connection to the plant and Cap_Bess is the capacity of the battery. 
        d_t is the time step and has to be in hours. Grid_Model represents the model of the grid
        """
        #Initiating the variables
        self.Freq_Data = Freq_Data; 
        self.SoC_0= SoC_0; self.P_D_Max = P_D_Max; self.P_C_Max = P_C_Max; self.BESS_Cost = BESS_Cost
        self.Load_Curve = Load_Curve; self.P_Cap = P_Cap; self.Cap_BESS = Cap_BESS; self.d_t = d_t
        self.Cost_Peak = Cost_Peak
        self.El_Price = El_Price
        self.Prev_Peak = Prev_Peak
        

        #Maximum load over the analysed timespan
        self.Max_Load = Max_Load
        #This is highly dependent on the format of the data
        self.FCR_Price_N_Upp = FCR_Price[:,0] # Knowing that this will be both up and down regulation
        self.FCR_Price_N_Down = FCR_Price[:,1]
        #The bidd prices will be sent as an array of two columns
        self.FCR_Bid_Price_N = FCR_Bid_Price[:,0]
        self.FCR_Bid_Price_D = FCR_Bid_Price[:,1]

        #Number of samples that the program analyses
        self.N_Samples = len(Freq_Data)
        #Number of hours that we analyse
        self.N_Hours = len(self.FCR_Price_N_Upp) 
        #Samples per hour
        self.N_Samples_Hour = round(self.N_Samples/self.N_Hours)
        #Samples of SoC we will have one more sample for the SoC variables due to that 
        #I have to calculate the SoC at midnight between each month
        self.N_Samples_SoC = self.N_Samples +1

        

    def Set_Bounds(self):
        
        #Generating the lower and upper bounds of the variables 
        
        #Soc this will have to be one more variable compared to the power since I have to calculate the SoC
        #at midnight at the end of each month
        lb_SoC = np.zeros(self.N_Samples_SoC); ub_SoC = np.full(self.N_Samples_SoC,1)

        #P_FCR_Bid, hourly values. Here we also assume 

        lb_FCR_N_Bid = np.zeros(self.N_Hours) #Going to be the same irrespective
        ub_FCR_N_Bid = np.empty(self.N_Hours)
        for a in range(self.N_Hours):
            #Check which is the least the capacity, the charge, discharge power or the avialable capacity
            ub_FCR_N_Bid[a] = np.amin([0.5*self.Cap_BESS,self.P_D_Max,self.P_C_Max, self.P_Cap - self.Load_Curve[a,0]])
        
        
        #FCR_D_Bid, hourly values
        lb_FCR_D_Bid = np.zeros(self.N_Hours); ub_FCR_D_Bid = np.full(self.N_Hours, np.amin([self.Cap_BESS/(20/60),self.P_D_Max]))
        #P_FCR_D, same size as freqdata
        lb_FCR_D = np.full(self.N_Samples,-self.P_D_Max); ub_FCR_D = np.zeros(self.N_Samples)
        #P_FCR_N, same size as freqdata 
        lb_FCR_N = np.full(self.N_Samples,-self.P_D_Max); ub_FCR_N = np.full(self.N_Samples,self.P_C_Max)
        #P_Energy, same size as freqdata 
        lb_Energy = np.full(self.N_Samples_Hour, np.amax([-self.P_Cap - self.Load_Curve[0,0], -self.P_D_Max]))
        ub_Energy = np.full(self.N_Samples_Hour, np.amin([self.P_Cap - self.Load_Curve[0,0], self.P_C_Max]))

        for a in range(1,self.N_Hours):
            #Generating the load curve
            lb_Energy = np.concatenate((lb_Energy,np.full(self.N_Samples_Hour, np.amax([-self.P_Cap - self.Load_Curve[a,0], -self.P_D_Max]))), axis= 0)
            ub_Energy = np.concatenate((ub_Energy,np.full(self.N_Samples_Hour,np.amin([self.P_Cap - self.Load_Curve[a,0], self.P_C_Max]))), axis= 0)

        lb_N_Cycles = np.zeros(1); ub_N_Cycles = np.full(1, 6000)
        
        #Creating the lower bounds lb in the order I want to define my variables
        lb = np.concatenate((lb_SoC, lb_FCR_N_Bid, lb_FCR_N, lb_FCR_D_Bid, lb_FCR_D,
         lb_Energy, lb_N_Cycles))
        
        #Generating the upperbounds up
        ub = np.concatenate((ub_SoC, ub_FCR_N_Bid, ub_FCR_N, ub_FCR_D_Bid, ub_FCR_D,
         ub_Energy, ub_N_Cycles))
        return lb,ub

    def Set_Linear_Const(self):
        #Defining the linear constraints of the solver
        """
        | 1 2| |x_0|  = Constant
        | 2 1| |x_1|  = Constant
        """

        #Constraints are defined as c_lower and C_upper. Provided if C_lower = C_upper then the
        #constraint will be an equality constraint. Generate a Matrix that we'll fill with constants
        A_Lin_Const = np.zeros((2*self.N_Samples + self.N_Samples_SoC + 2*self.N_Hours,
        self.N_Samples_SoC + 3*self.N_Samples + 2*self.N_Hours + 1), dtype= np.float64)
        

        #Now I have to define the bound imposed on the state of charge that will be approximated through a 
        #linearization SoC(t+delta_t) = SoC(t) + P_BESS(t)*delta_t/Cap_BESS which realises a zero order hold
        #approximation

        #First constriant will be the intial state of charge 
        A_Lin_Const[0,0] = 1 #Indicating that the SoC of the current time step will be active in the const
        lb_SoC = np.zeros(self.N_Samples_SoC)
        lb_SoC[0] = self.SoC_0 #Initial condition
        ub_SoC = lb_SoC.copy()

        #Replacing the correct elements
        Iteration = 1
        for a in range(1,self.N_Samples_SoC):
            A_Lin_Const[a,Iteration] = self.Cap_BESS #Current Value SoC(t+delta_t)
            A_Lin_Const[a,Iteration-1] = -self.Cap_BESS #Previous value SoC(t)
            #The power being charge/discharge to/from the battery
            #P_FCR_N
            A_Lin_Const[a,self.N_Samples_SoC + self.N_Hours + Iteration-1] = -self.d_t 
            #P_FCR_D
            A_Lin_Const[a,self.N_Samples_SoC + 2*self.N_Hours + self.N_Samples + Iteration-1] = -self.d_t
            #P_Energy
            A_Lin_Const[a,self.N_Samples_SoC + 2*self.N_Hours + 2*self.N_Samples + Iteration-1] = -self.d_t
            
            Iteration += 1

        #Constructing the linear constraints for the bidding size
        #Starting with the FCR_N bidding sizes where the required amount of energy that is  before the bid
        #available is the limiting factor: E_avial = SoC(t-delta_t)*Cap_Bat/1 hour

        #As we know the time_step, i.e that the frequency data is in minutes for instance we can find the SoC
        #just before every hour. It becomes at the start of each hour. 
       
        Iteration_SoC = 0
        Iteration_P_Bid = 0
        for a in range(self.N_Samples_SoC,self.N_Samples_SoC + self.N_Hours):
                       
            #FCR_D_Bid, where I also have to include the constraint of the FCR_N_Bid
            A_Lin_Const[a,Iteration_SoC] = -self.Cap_BESS*3
            A_Lin_Const[a,self.N_Samples_SoC + Iteration_P_Bid] = 3 #FCR_N bid constraining the FCR_D
            A_Lin_Const[a,self.N_Samples_SoC + self.N_Samples + self.N_Hours + Iteration_P_Bid] = 1 #FCR_D_Bid

            Iteration_SoC += self.N_Samples_Hour
            

            Iteration_P_Bid += 1

        #Generating the lower and upper bounds for the bidding
        lb_P_Bids = np.full(self.N_Hours,np.NINF) #Negative infinity
        ub_P_Bids = np.zeros(self.N_Hours)     


        #Defining the constraints for the grid model where the demands of P_FCR_N and P_FCR_D are defined. 
        #These will be linear as P_demand = (f-f_0)*P_bid
        f_0 = 50 #Hz
        #Average frequency feviation every sample
        d_f = self.Freq_Data - f_0

        #For loop bounds
        Upper_Bound = self.N_Samples + self.N_Samples_SoC + self.N_Hours
        Lower_Bound = self.N_Samples_SoC + self.N_Hours
        Iteration = 0
        Iteration_P_Bid = 0
        
        for a in range(Lower_Bound, Upper_Bound):
            A_Lin_Const[a,self.N_Samples_SoC + self.N_Hours + Iteration] = 1 #FCR_N Constraint
            if np.abs(d_f[Iteration]) < 0.1: #Checking if the frequency is within the opperation region for FCR_N
                A_Lin_Const[a,self.N_Samples_SoC + Iteration_P_Bid] = -(d_f[Iteration]/0.1) #Effectively the bid times the deviation in freq
            elif np.abs(d_f[Iteration]) >= 0.1 and d_f[Iteration] < 0:
                A_Lin_Const[a,self.N_Samples_SoC + Iteration_P_Bid] = 1 #Caps out at 100, the sign is however of importance
            elif np.abs(d_f[Iteration]) >= 0.1 and d_f[Iteration] > 0:
                 A_Lin_Const[a,self.N_Samples_SoC + Iteration_P_Bid] = -1 #Caps out at 100, the sign is however of importance
            
            A_Lin_Const[a+self.N_Samples,self.N_Samples_SoC + self.N_Samples + 2*self.N_Hours + Iteration] = 1 #FCR_D constraint
            #Will only regulate at frequencies bellow the nominal freq.
            if d_f[Iteration] < -0.1 and d_f[Iteration] > -0.5: 
                A_Lin_Const[a+self.N_Samples,self.N_Samples_SoC + self.N_Samples + self.N_Hours + Iteration_P_Bid] = -(d_f[Iteration]-0.1)/(0.4)
            elif d_f[Iteration] <= -0.5:
                A_Lin_Const[a+self.N_Samples,self.N_Samples_SoC + self.N_Samples + self.N_Hours + Iteration_P_Bid] = 1
                       
            #Want to have a fixed bid each hour:
            if (Iteration + 1) % self.N_Samples_Hour == 0: #Checking when an hour has passed
                Iteration_P_Bid += 1 #Take one more step

            Iteration += 1
        
        ub_P_FCR = np.zeros(2*self.N_Samples)
        lb_P_FCR = ub_P_FCR.copy()  
        
        Upper_Bound = 2*self.N_Samples + self.N_Samples_SoC + 2*self.N_Hours
        Lower_Bound = 2*self.N_Samples + self.N_Samples_SoC + self.N_Hours
        Iteration_P_Bid = 0
        for a in range(Lower_Bound,Upper_Bound):

            A_Lin_Const[a,self.N_Samples_SoC + Iteration_P_Bid] = 1 #FCR_N bid constraining the FCR_D
            A_Lin_Const[a,self.N_Samples_SoC+self.N_Samples + self.N_Hours + Iteration_P_Bid] = 1 #FCR_D_Bid

            Iteration_P_Bid += 1
        
        lb_Bid_Sum = np.zeros(self.N_Hours)
        ub_Bid_Sum = np.empty(self.N_Hours)
        for a in range(self.N_Hours):
            #Looping over the amount of hours to generate the bounds of the constraint
            ub_Bid_Sum[a] = np.amin([self.P_D_Max,self.P_Cap + self.Load_Curve[a,0]])

        #Imposing a constraint 
        

        #Defining lower bounds and upper bounds: lb and ub
        lb = np.concatenate((lb_SoC, lb_P_Bids, lb_P_FCR, lb_Bid_Sum))
        ub = np.concatenate((ub_SoC, ub_P_Bids, ub_P_FCR, ub_Bid_Sum))

        #Returning the linear constraints as and object
        return A_Lin_Const, lb, ub

    
    def FCR_N_Bidding_Const(self,x):
        #Have to impose constraints on the FCR_N bids that reflect the SoC accuratly

        #May use an absolute function to approximate the SoC
        Bid_Const = np.empty(self.N_Hours)
        Iteration_SoC = 0
    
        for a in range(self.N_Hours):

            Bid_Const[a] = (0.5 - np.abs(x[a + Iteration_SoC] - 0.5))*self.Cap_BESS #Max when equal 0.5
            #updating the SoC_Index
            Iteration_SoC += self.N_Samples_Hour
        

        Index_FCR_N_Bid = self.N_Samples_SoC 
        
        return - Bid_Const + x[Index_FCR_N_Bid:self.N_Hours+ Index_FCR_N_Bid] 

    def FCR_Bidding_Const_Jac(self,x):
        #The jacobian of the bidding constaint named Jac_Matrix
        Jac_Matrix = np.zeros((self.N_Hours,self.N_Samples*3+2*self.N_Hours + 1 + self.N_Samples_SoC))

        Derrivative = lambda Var: 1.9894 -2*13.6261*Var + 3*67.8774*Var\
            - 4*145.3696*Var**3 + 5*133.5499*Var**4 - 6*44.3152*Var**5 -7*0.1058*Var**6

        Index_FCR_N_Bid = self.N_Samples_SoC 
        Iteration_SoC = 0
        for a in range(self.N_Hours):
            Jac_Matrix[a,Iteration_SoC] =  -Derrivative(x[Iteration_SoC])*self.Cap_BESS

            Jac_Matrix[a,a + Index_FCR_N_Bid] = 1

            Iteration_SoC += self.N_Samples_Hour

        return Jac_Matrix
    
    def BESS_Throughput(self,x):
        #Through put function used to estimate the number of cycles the battery undergoes
        y = x[0:self.N_Samples_SoC]
        max_min = []
        max_min.append(y[0])
        for i in range(len(y)-2):
            if y[i+1]>y[i] and y[i+1]>y[i+2]:
                max_min.append(y[i+1])
            elif y[i+1]<y[i] and y[i+1]<y[i+2]:
                max_min.append(y[i+1]) 
        max_min.append(y[-1])
        cycle_count = 0
        discharge = 0
        for i in range(1,len(max_min)):
            if max_min[i]<max_min[i-1]:
                discharge += max_min[i-1]-max_min[i]
                #if discharge>=1:
                    #cycle_count +=1
                    #discharge = discharge%1
        return -discharge + x[-1]

    def Rainflow(self,x):
        #Rainflow algorithm used to estimate the cycles 
        y = x[0:self.N_Samples_SoC]
        max_min = []
        max_min.append(y[0])
        for i in range(len(y)-2):
            if y[i+1]>y[i] and y[i+1]>y[i+2]:
                max_min.append(y[i+1])
            elif y[i+1]<y[i] and y[i+1]<y[i+2]:
                max_min.append(y[i+1]) 
        max_min.append(y[-1])
        result_n = 0
        count = 0
        index = -1
        temp =np.zeros(len(max_min))
        result = np.zeros((len(max_min),2))
        for i in range(len(max_min)):
            index = index+1
            temp[index] = max_min[count]
            count = count+1
            while index>=2 and abs(temp[index]-temp[index-1])>abs(temp[index-1]-temp[index-2]):
                mean = abs(temp[index-1]-temp[index-2])
                if index==2:
                    result[result_n,0] = 0.5
                    result[result_n,1] = mean
                    result_n = result_n+1
                    temp[0]=temp[1]
                    temp[1]=temp[2]
                    index = 1
                else:
                    result[result_n,0] = 1
                    result[result_n,1] = mean
                    temp[index-2] = temp[index]
                    index = index-2
                    result_n = result_n+1
        for i in range(index):
            mean = abs(temp[i]-temp[i+1])
            result[result_n,0] = 0.5
            result[result_n,1] = mean
            result_n = result_n+1
        result = [[x[0], x[1]] for x in result if x[0] != 0 and x[1] != 0]
        result = np.array(result)
        if len(max_min) < 3:
            return 0 + x[-1]
        else: 
            return -result[:,0].sum() + x[-1]


    def Bidding_Const(self,x):
        #We want to ensure that the product of the P_energy and the FCR bids are zero
        #we may do this by multiplying the constraints
        
        Index_FCR_N = self.N_Samples_SoC 
        Index_FCR_D = self.N_Samples_SoC + self.N_Samples + self.N_Hours

        FCR_N_Bids = np.full(self.N_Samples_Hour,x[Index_FCR_N])
        FCR_D_Bids = np.full(self.N_Samples_Hour,x[Index_FCR_D])

        for i in range(1,self.N_Hours):
            FCR_N_Bids = np.concatenate((FCR_N_Bids,np.full(self.N_Samples_Hour,x[Index_FCR_N+i])))
            FCR_D_Bids = np.concatenate((FCR_D_Bids,np.full(self.N_Samples_Hour,x[Index_FCR_D+i])))


        Index_P_Energy = self.N_Samples_SoC + self.N_Samples*2 + self.N_Hours*2
        return FCR_N_Bids*x[Index_P_Energy:Index_P_Energy + self.N_Samples] + \
            FCR_D_Bids*x[Index_P_Energy:Index_P_Energy + self.N_Samples]

    def Bidding_Const_Jac(self,x):
        #Jacobian of the bidding constraint of the FCR_N, FCR_D and the use of P_Energy
        
        Jac_Matrix = np.zeros((self.N_Samples,self.N_Samples*3 + self.N_Samples_SoC + self.N_Hours*2+1))
        
        #Bidding index
        Index_FCR_N_Bids = self.N_Samples_SoC 
        Index_FCR_D_Bids = self.N_Samples_SoC + self.N_Samples + self.N_Hours

        Index_P_Energy = self.N_Hours*2 + self.N_Samples_SoC + self.N_Samples*2

        Iteration = 0
        Iteration_P_Bid = 0         
        for a in range(self.N_Samples):
            
            Jac_Matrix[a,Index_P_Energy + Iteration] = x[Index_FCR_N_Bids + Iteration_P_Bid] + x[Iteration_P_Bid + Index_FCR_D_Bids]
            #Partial derivative with respect to the FCR_N Bid
            Jac_Matrix[a, Index_FCR_N_Bids + Iteration_P_Bid] = x[Index_P_Energy + Iteration]
            #Partial derivative with respect to the FCR_D Bid
            Jac_Matrix[a, Index_FCR_D_Bids + Iteration_P_Bid] = x[Index_P_Energy + Iteration]

            #Want to have a fixed bid each hour:
            if (Iteration + 1) % self.N_Samples_Hour == 0: #Checking when an hour has passed
                Iteration_P_Bid += 1 #Take one more step
            Iteration += 1

        #Jacobian Matrix that the solver will use 
        return Jac_Matrix

    def Bidding_Const_Hess(self,x,v):
        #Hessian of the non linear bid constraint
        n = self.N_Samples_SoC + self.N_Hours*2 +1 + self.N_Samples*3 #number of variables
        Hess_Matrix = np.zeros((n,n))
        Index_P_FCR_N = self.N_Samples_SoC 
        Index_P_FCR_D = Index_P_FCR_N + self.N_Hours + self.N_Samples
        Index_P_Energy = Index_P_FCR_D + self.N_Hours + self.N_Samples

        Iteration = 0
        Iteration_P_Bid = 0
        for a in range(self.N_Samples):
            #Creating one matrix for every time step
            Hess_Matrix_Temp = np.zeros((n,n))
            #Only non-zero first derivatives will be in P_energy, P_FCR-D and P_FCR-N bids
            
            #First derivative P_energy and seccond depends on P_bid FCR-N or D
            Hess_Matrix_Temp[Index_P_FCR_N + Iteration_P_Bid, Index_P_Energy + Iteration] = 1
            Hess_Matrix_Temp[Index_P_FCR_D + Iteration_P_Bid, Index_P_Energy + Iteration] = 1

            #First derivative P_FCR-D
            Hess_Matrix_Temp[Iteration + Index_P_Energy, Index_P_FCR_D + Iteration_P_Bid] = 1

            #First derivative P_FCR-N
            Hess_Matrix_Temp[Iteration + Index_P_Energy, Index_P_FCR_N + Iteration_P_Bid] = 1

            Hess_Matrix = Hess_Matrix + v[a]*Hess_Matrix_Temp
            if (Iteration + 1) % self.N_Samples_Hour == 0: #Checking when an hour has passed
                Iteration_P_Bid += 1 #Take one more step
            Iteration += 1

        return Hess_Matrix

    def Objective_Function(self,x):
        #Objective function to the optimization problem, the contributing costs are divided into C_peak estimating
        #the savings that might be achieve through peak shaving, C_energy which is the energy cost when the BESS
        #is not used for grid supporting services, C_FCR which is the revenue associated with the FCR and finally
        #C_BESS is the cost associated with degrading the Battery
        
        #Defining savings associated with the peak shaving C_peak = max(P_Load) - max(P_Grid)
        #This turns into a cost whenever the maximum is higher than the original load

        Index = self.N_Samples_SoC + self.N_Samples*2 + self.N_Hours*2
        Peak_Vector = np.empty(self.N_Hours)
        #Iteration_Load = 0
        for a in range(self.N_Hours):
            #Minutes = self.N_Samples_Hour*a
            Peak_Vector[a] = self.Load_Curve[a,0] + np.mean(x[Index + a*self.N_Samples_Hour:Index + (1+a)*self.N_Samples_Hour])
            #if (a + 1) % self.N_Samples_Hour == 0: #Checking when an hour has passed
                #Iteration_Load += 1 #Take one more step
        if np.amax(Peak_Vector) > self.Prev_Peak:
            #Then we want to identify the cost of this new peak
            C_Peak = (self.Max_Load - np.amax(Peak_Vector))*self.Cost_Peak #Cost in Euros
        else: 
            #Just to make it continous
            C_Peak = (self.Max_Load - self.Prev_Peak)*self.Cost_Peak 
                
        #Defning the cost to charge our battery outside the spann of FCR C_energy = Electricity_Price*Energy
        C_Energy = 0 #Initiating the varaible 
        
        if isinstance(self.El_Price, float):
            #Meaning that we have a fixed price for the electricity
            Index = self.N_Samples_SoC + self.N_Samples*2 + self.N_Hours*2
            C_Energy =  self.El_Price*np.sum(x[Index:Index + self.N_Samples])*self.d_t
        else: #Know that the spotprices are 
            Iteration_Energy_Price = 0
            Index = self.N_Samples_SoC + self.N_Samples*2 + self.N_Hours*2
            for a in range(self.N_Samples):
                #Calculating the cost using the spot given each hour. 
                C_Energy +=  x[Index+a]*self.El_Price[Iteration_Energy_Price,0]
                if (a + 1) % self.N_Samples_Hour == 0: #Checking when an hour has passed
                    Iteration_Energy_Price += 1 #Take one more step
            C_Energy = C_Energy*self.d_t/1000

        #Defining the revenue of the C_FCR = C_Bid + C_FCR_N_Energy
        #As we only get paid for the activated energy FCR-N we'll only have to consider that when calculating
        #the price of the activated energy. This is done for every quater that the FCR-N is activated

        C_FCR = 0
        #print(np.shape(self.FCR_Bid_Price_N))
        #print(np.shape(x[self.N_Samples_SoC + self.N_Samples*2:self.N_Samples_SoC + self.N_Samples*2 + self.N_Hours]))
        #Revenue off the bids P_bid @ x:
        Index_FCR_N = self.N_Samples_SoC
        Index_FCR_D =self.N_Samples_SoC + self.N_Samples + self.N_Hours
        C_FCR = np.dot(self.FCR_Bid_Price_N, x[Index_FCR_N: Index_FCR_N + self.N_Hours]) \
            + np.dot(self.FCR_Bid_Price_D, x[Index_FCR_D:Index_FCR_D +self.N_Hours])
        
        #Now it's important to distinguish between when the BESS is opperating in FCR_N_Upp and FCR_N_Down
        One_quater = int(self.N_Samples_Hour/4)
        
        for a in range(self.N_Hours):
            #Identify when P_FCR_N is negative or postive each 15 min which means that I have to divide by 4 and
            #convert the energy price to EUR/MWh
            Index = a*self.N_Samples_Hour + self.N_Samples_SoC + self.N_Hours

            #Calculating the revenue
            First_15 = np.mean(x[Index:Index + One_quater])
            if First_15 < 0:
                 C_FCR += np.abs(First_15)*self.FCR_Price_N_Upp[a]/4 #In EUR/MWh
                 
            elif First_15 >= 0:
                 C_FCR += First_15*self.FCR_Price_N_Down[a]/4
            Seccond_15 = np.mean(x[Index + One_quater: Index + One_quater*2])
            
            if Seccond_15 < 0:
                 C_FCR += np.abs(Seccond_15)*self.FCR_Price_N_Upp[a]/4
            elif Seccond_15 >= 0:
                 C_FCR += Seccond_15*self.FCR_Price_N_Down[a]/4
            Third_15 = np.mean(x[Index + One_quater*2: Index +One_quater*3])
            
            if Third_15 < 0:
                 C_FCR += np.abs(Third_15)*self.FCR_Price_N_Upp[a]/4
            elif Third_15 >= 0:
                 C_FCR += Third_15*self.FCR_Price_N_Down[a]/4
            Last_15 = np.mean(x[Index + One_quater*3:Index + self.N_Samples_Hour]) 
            if Last_15 < 0:
                 C_FCR += np.abs(Last_15)*self.FCR_Price_N_Upp[a]/4
            elif Last_15 >= 0:
                 C_FCR += Last_15*self.FCR_Price_N_Down[a]/4
           
        #The cost of the BESS is dependent of the service costs and the degredation cost
        #N_Rated_Cycl is the expected number of cycles the BESS can handle
        N_Rated_Cycl = 6000
        #Estimated life time 
        Est_Life = 10 #Years
        Avg_N_Days = 30.42 #Average number of days a month
        if N_Rated_Cycl/(Est_Life*Avg_N_Days*12) < x[-1]:
            C_BESS = x[-1]/N_Rated_Cycl*self.BESS_Cost #We have a small buffer that we might use to burn down the battery. 
        else:
            C_BESS = 0
        
        
        #Here the resulting cost is returned to the optimization tool with respect to minimization
        return C_BESS - C_Peak + C_Energy - C_FCR/1000 
#Importing Data for Excel files 
import csv

import os
from pathlib import Path
from os import error, listdir
import pandas as pd
import numpy as np
from pandas._libs.tslibs.timestamps import Timestamp
from pandas.core.reshape.concat import concat
from pandas.core.tools.numeric import to_numeric


def Freq_DataImport(folder):
    #Number of files with missing data 
    Num_Miss_Data = 0
    i = 1
    path = Path(folder)
    Monthly_Freq_Data = 0
    #List all the folders 
    for entry in os.scandir(folder):
            #Control if it's a directory
            if entry.is_dir():
                Directory_path = entry
                
                filenames = cvs_files(Directory_path)
                #Printing the name of the month that's processed
                print("Processing frequency data of month:")
                print(entry.name)
                
                
                for item in filenames:
                    
                    #File path
                    file_to_open = path / entry.name / item
                    #Reading the file using csv and setting the date time as an index
                    Freq_Data = pd.read_csv(file_to_open,sep=',', header=0, parse_dates=['Time'], dayfirst=True,
                    infer_datetime_format=True)
                    
                    #Checking if the data frame is empty
                    if len(Freq_Data) != 0:
                        Last_date =Freq_Data.iloc[-1]  
                        First_date = Freq_Data.iloc[0]                
                    Date = item.split('.')

                    #Checking if data is missing entierly or have some missing values
                    if pd.Timestamp(Date[0] + ' 23:59:59.900000') != pd.Timestamp(Last_date.Time) or \
                        pd.Timestamp(Date[0] + ' 00:00:00.000000') != pd.Timestamp(First_date.Time) or len(Freq_Data) == 0 :
                        #Provided if data frame is empty
                        Num_Miss_Data += 1

                        
                        Monthly_Freq_Data = Data_Extrapolation(Date[0],Num_Miss_Data, Monthly_Freq_Data )
                        

                    else:
                            #Resampeling the data into seconds    
                        Resampled_Freq_Data = Freq_Data.resample('15min', on = 'Time').mean()
                        if i == 1:
                            #Monthly frequency data
                            Monthly_Freq_Data  =  Resampled_Freq_Data
                            i = 2
                        else:
                            #Just an index
                            Num_Miss_Data = 0
                            #Adding next days to the data frame
                    
                            Monthly_Freq_Data = pd.concat([ Monthly_Freq_Data,Resampled_Freq_Data])
                    
    #Renaming the   
    Monthly_Freq_Data = Monthly_Freq_Data.rename(columns={'Value':'Frequency'})
    
    return Monthly_Freq_Data


def cvs_files(path):
    #Finding the cvs files stored within that folder. Done mostly to not have to find
    Filenames = os.listdir(path)
    csv_files_names = []
    for item in Filenames:
        if item.endswith('.csv'):
            csv_files_names.append(item)
    return csv_files_names

def Data_Extrapolation(Date,Num_Miss_Data,Freq_Data):
    #Extrapolate the missing data by writing over using previous data
    print("Identified missing data for day " + Date)
    Date_String = Date.split('-')
    #Finding the day that I want to sample from
    Previous_Previous_Day = int(Date_String[2]) - (Num_Miss_Data)
    if Previous_Previous_Day < 10:
        Date_String_old_start = Date_String[0]+ '-' + Date_String[1] + '-0%d 00:00:00'% Previous_Previous_Day
        Date_String_old_end = Date_String[0]+ '-' + Date_String[1] + '-0%d 23:59:00'% Previous_Previous_Day
    else:
        Date_String_old_start = Date_String[0]+ '-' + Date_String[1] + '-%d 00:00:00' % Previous_Previous_Day
        Date_String_old_end = Date_String[0]+ '-' + Date_String[1] + '-%d 23:59:00'% Previous_Previous_Day
    #Finding the frequency of the previous day
    
    Freq_Readings = Freq_Data.loc[Date_String_old_start:Date_String_old_end,'Value']
    
    
    Freq_Values =  Freq_Readings.to_numpy()
    #Adding some random noice to the singal so the same day doesn't repeat over and over
    noise = np.random.normal(0,0.01,Freq_Values.shape) #May be changed
 
    Freq_Values = Freq_Values + noise
    #Defining the statring and ending date/time in which is should generate my date_ranges
    Start_Date = Date_String[0]+'-'+Date_String[1]+'-'+Date_String[2] 
    
    #Creating a new datafram containing data over the "new" day
    Extrapolated_Dates = pd.date_range(Start_Date,freq = '15min',name='Time', periods = 1440/15)
    
    Extrapolated_Data = pd.DataFrame(data = Freq_Values,index = Extrapolated_Dates,columns = ['Value'])
    #Returning the old data frame with a new added to it
    return pd.concat([ Freq_Data ,Extrapolated_Data])

def Regulating_Bid_Prices(folder):
    #Importing and processing the Regulating bid Prices which are listed in EUR/MW
    path_to_folder = Path(folder)

    #Define path to the file 
    file_to_open = path_to_folder / 'FCR Bid Prices' / 'Primärreglering.csv'
    #Reading the file
    Regulating_Bid_Data = pd.read_csv(file_to_open,header = 0, sep=';', index_col= ['Period'], 
    parse_dates=['Period'], infer_datetime_format= True, skipfooter= 1, engine= 'python',
    usecols=['Period','FCR-N Pris (EUR/MW)','FCR-D Pris (EUR/MW)'])

    #Renaming the columns
    Regulating_Bid_Data = Regulating_Bid_Data.rename(columns={ 
    'FCR-N Pris (EUR/MW)':'FCR-N','FCR-D Pris (EUR/MW)':'FCR-D'})
    #Renaming the index axis
    Regulating_Bid_Data = Regulating_Bid_Data.rename_axis(['Time']) 
    Regulating_Bid_Data = Regulating_Bid_Data.apply(lambda x: x.str.replace(",","."))  

    return Regulating_Bid_Data



def Regulating_Prices(folder):
    #Importing and and processing the prices for the FCR-N service
    path_to_folder = Path(folder)

    #Define path to the file 
    file_to_open = path_to_folder / 'FCR Regulating Prices' / 'Data.xls'
    
    #Redaing the excel file
    Regulating_Price_Data = pd.read_excel(file_to_open, engine='xlrd', skiprows=4,
    usecols=[0,1,12,13,14,15,16,17,18,19], header = None, parse_dates={'Time' :[0,1]},
    date_parser= lambda x: Date_Time_Parser(x))
    
    #Change column names 
    Regulating_Price_Data = Regulating_Price_Data.rename(columns={12:'SE1:Up', 13:'SE1:Down', 14:'SE2:Up',
    15:'SE2:Down', 16:'SE3:Up',17:'SE3:Down',18:'SE4:Up',19:'SE4:Down'})

    #Update the index of the dataframe
    Regulating_Price_Data = Regulating_Price_Data.set_index(['Time'])

    
    return Regulating_Price_Data

def Date_Time_Parser(Date_to_Parse):
    #Parsing Dates in format %Y-%m-%d %H-%H to get it in a format of 
    # %Y-%m-%d %H where $H represents the initial hour
    Date_to_Parse = Date_to_Parse.split(' ')
    Hours = Date_to_Parse[1].split('-')
    
    Parsed_date = pd.to_datetime(Date_to_Parse[0]+ ' ' + Hours[0])
    return Parsed_date

def Load_Data_Reader(Folder,sheet):
    #Reading the data for the load profile, where I assume a fixed format on the information
    Path_to_Folder  = Path(Folder)

    file_to_open = Path_to_Folder / 'load profiles.xlsx'

    Load_Data = pd.read_excel(file_to_open, sheet_name = sheet, 
    usecols= ['Time','Load'], parse_dates= ['Time'])

    #Updating the index
    Load_Data = Load_Data.set_index(['Time'])
    
    return Load_Data


def Spot_Price_Reader(Folder):
    #Reading the data for the spot price
    Path_to_Folder = Path(Folder)

    file_to_open = Path_to_Folder /'Spot Price'/'Elspot_Prices.xls'
    #Spot prices in Euro
    Spot_Price_Data = pd.read_excel(file_to_open, engine='xlrd', skiprows=3,
    usecols=[0,1,3,4,5,6], header = None, parse_dates={'Time' :[0,1]},
    date_parser= lambda x: Date_Time_Parser(x))

    Spot_Price_Data = Spot_Price_Data.rename(columns = {3:'SE1',4:'SE2',5:'SE3',6:'SE4'})
    Spot_Price_Data = Spot_Price_Data.set_index(['Time'])
    
    

    return Spot_Price_Data



#Main programme for the BESS optimization tool Group 2 EI2525
from typing import Reversible
import numpy as np
import matplotlib.pyplot as plt
from numpy.core.multiarray import zeros
from numpy.core.shape_base import block
import pandas as pd
import os

from pandas.core.frame import DataFrame


import Data_Import 
from Optimization_Alg import Charge_Controller
from scipy.optimize import Bounds
from scipy.optimize import LinearConstraint
from scipy.optimize import NonlinearConstraint
from scipy.optimize import minimize
from scipy.optimize import BFGS
from scipy.optimize import SR1




class User_termination(Exception):
    pass


def main():
    #Main programme calling each sub instance required for the solver
    
    #Inquiring for the necessary data from the user
    BESS_Size_Max, BESS_Size_Min, BESS_Initial_Size, \
    El_Price, Choice_Energy_Reg, Peak_Cost = User_input()
    """
    BESS_Size_Max = 384.0
    BESS_Size_Min = 76.8
    BESS_Initial_Size =  76.8#230.4
    Grid_Cap = 100
    El_Price, Choice_Energy_Reg = Electricity_Price_Sel()
    #Choice_Energy_Reg = "SE4"
    Peak_Cost = 6 #Peak cost of the 
    BESS_Serv_Cost = 10
    """

    #What data should I drop
    if Choice_Energy_Reg.upper() == "SE1":
        Data_to_Drop = ["SE2","SE3","SE4"]
    elif Choice_Energy_Reg.upper() == "SE2":
        Data_to_Drop = ["SE1","SE3","SE4"]
    elif Choice_Energy_Reg.upper() == "SE3":
        Data_to_Drop = ["SE1","SE2","SE4"]
    elif Choice_Energy_Reg.upper() == "SE4":
        Data_to_Drop = ["SE1","SE2","SE3"]
    
    print("Fetching Data.")
    folder = 'Frequency Data'
    print("Fetching frequency data...")
    Monthly_Freq_data = Data_Import.Freq_DataImport(folder)
    
    #Illustrating the data in a plot using 
    #Monthly_Freq_data.plot(y = 'Frequency', kind='line')
    #plt.show()
   
    print("Obtaining the regulating bid prices...")
    #Obtaining the FCR prices for each region
    Folder_Regulating_Prices = 'Prices and Revenue'
    FCR_Bid_Prices = Data_Import.Regulating_Bid_Prices(Folder_Regulating_Prices)
    
    #Obtaining the FCR-N regulating prices 
    print("Obtaining the regulating prices...")
    FCR_Prices = Data_Import.Regulating_Prices(Folder_Regulating_Prices)
    

    #Dropping the data that we don't need 
    
    for a in range(len(Data_to_Drop)):
        Columns_to_Drop_Up = Data_to_Drop[a] + ':Up'
        Columns_to_Drop_Down = Data_to_Drop[a] + ':Down'
        FCR_Prices = FCR_Prices.drop(columns = [Columns_to_Drop_Up, Columns_to_Drop_Down])

    print("Loading the load data...")
    #Read the load data here
    folder_name = "Load Data" #Defines the sheet that should be read. 
    Load_Profile = Data_Import.Load_Data_Reader(folder_name,1)

    #Findign the maximum value of the Load profile and 
    Max_Load = np.amax(Load_Profile.to_numpy())

    #Rounding up to the nearest multiple of a cerain value
    Grid_Cap = np.ceil(1.3*Max_Load/10)*10 #Go in steps of 10 awhile ensuring that we have atleast
    #50 percent of the maximum capacity
    print("Assumed Grid Capacity in [kW].")
    print(Grid_Cap)
    
    print('Initiating the solver')
    #Permissable battery size between the maximum size and the minimum size
    BESS_Array,Charge_Array, Discharge_Array = BESS_Vector(BESS_Size_Max, BESS_Size_Min)

    #Solving for the most profitable/Cheapest battery size
    Optimal_BESS, Highest_Revenue,N_Cycles, BESS_Cost = BESS_Iterator(BESS_Array= BESS_Array, Charge_Array= Charge_Array,
    Discharge_Array=Discharge_Array, Initial_BESS= BESS_Initial_Size, Frequency_Data= Monthly_Freq_data,
    FCR_Bid_Price= FCR_Bid_Prices, FCR_Price= FCR_Prices, Load_Profile= Load_Profile , El_Price= El_Price, 
    Grid_Cap = Grid_Cap, Peak_Cost = Peak_Cost)

    #Illustrating the result of the final result
    msg = "Optimal BESS size is: " + str(Optimal_BESS) + " [kWh].\nExpected revenue: " + str(Highest_Revenue[0]) + " Euro."
    print(msg)

    msg = "Installment cost: " + str(BESS_Cost) + " Euro."
    print(msg)

    #Illustrating the price distribution
    Final_Result_Illustrator(Highest_Revenue)



def Final_Result_Illustrator(Est_Rev):
    #Illustrating the expected revenue
    
    lab = ["Peak Shaving Revenue","FCR Revenue","Energy Arbitrage Revenue"]
    Values = [Est_Rev[1]/Est_Rev[0]*100, Est_Rev[2]/Est_Rev[0]*100, Est_Rev[3]/Est_Rev[0]*100]

    plt.bar(x = lab, height = Values, color = ['navy','darkred','darkgreen'] )
    
    plt.title("Revenue Distribution")
    plt.ylabel("Revenue in [%]")
    plt.grid(True)
    
    plt.show()
    return


def Data_Illustrator(SoC, P_FCR_N_Bids, P_FCR_D_Bids, P_Energy, Monthly_Load_Profile,\
    Rev_FCR,Rev_Energy,Date_Index):
    #Illustrating the monthly data for our report
    
    N_Hours = len(P_FCR_N_Bids)
    N_Samples = len(P_Energy)
    N_Samples_Hour = int(N_Samples/N_Hours)
    Days = int(N_Hours/24)

    #Obtain the year and month
    Year_Month = Date_Index.split('-')
    Date_Start= Year_Month[0]+ "-" + Year_Month[1] + '-01 00:00:00'
    #Generating a date range to plot over
    Dates = pd.date_range(start=Date_Start, freq= '15min', name='Dates', periods=N_Samples)
    #Plotting the SoC of the BESS
    SoC_DF = pd.DataFrame(data=SoC, index=Dates, columns=['SoC'])
    
    SoC_DF.plot(y = 'SoC', kind='line', ylabel= "SoC [p.u]", grid= True, figsize=(3.5, 2))
    plt.show(block = False)
    #title= "SoC Evolution"

    #Illustrating the cycle number
    
    cycle_Count = np.zeros(1)
    discharge = 0
    for i in range(len(SoC)-1):
        if SoC[i] > SoC[i+1]: #Larger than the nex value
            discharge += SoC[i] - SoC[i+1]
        cycle_Count = np.append(cycle_Count,[discharge])
    

    Cycle_DF = pd.DataFrame(data=cycle_Count, index=Dates, columns=['$N_\mathrm{Cycles}$'])

    Cycle_DF.plot(y = '$N_\mathrm{Cycles}$', kind='line', ylabel= "N_\mathrm{Cycles} [p.u]", grid= True,figsize = (3.5, 2))
    plt.show(block = False)
        

    #Plotting the biddings
    #Creating an extended matrix for each bidding
    
    
    P_FCR_D_array = np.full(N_Samples_Hour,P_FCR_D_Bids[0])
    P_FCR_N_array = np.full(N_Samples_Hour,P_FCR_N_Bids[0])

    for a in range(1,N_Hours): #Creating arrays for plotting
        P_FCR_D_array = np.concatenate((P_FCR_D_array,np.full(N_Samples_Hour,P_FCR_D_Bids[a])))
        P_FCR_N_array = np.concatenate((P_FCR_N_array,np.full(N_Samples_Hour,P_FCR_N_Bids[a])))

    
    #Generating DataFrames 
    Column_Vals = np.column_stack((P_FCR_D_array,P_FCR_N_array,P_Energy))
    P_DF = pd.DataFrame(data=Column_Vals, index= Dates, columns=["$P_\mathrm{FCR-D,Bid}$", "$P_\mathrm{FCR-N,Bid}$","$P_\mathrm{Energy}$"])

    
    P_DF.plot(y = ["$P_\mathrm{FCR-D,Bid}$", "$P_\mathrm{FCR-N,Bid}$","$P_\mathrm{Energy}$"], style = ["-","-","-"], ylabel = "P [kW]",
        grid = True,figsize=(3.5, 2))
    plt.legend(loc="best")
    #title= "BESS Power Profile"

    #Generating the time series 

    Hours = pd.date_range(start=Date_Start,freq="H",name='Dates', periods= N_Hours)
    
    #Resampling the P_energy in order to depict the peak shaving
    Peak_Vector = np.empty(N_Hours)
    for a in range(N_Hours):
        Minutes = N_Samples_Hour*a
        Peak_Vector[a] = Monthly_Load_Profile[a] + np.mean(P_Energy[Minutes:Minutes + N_Samples_Hour])

    
    Load_Data = np.column_stack([Peak_Vector,Monthly_Load_Profile[0:N_Hours]])
    #Plotting the load Profile 
    P_Load = pd.DataFrame(data=Load_Data,index = Hours, columns=['Peak Shaved Load Profile','Load Profile'])
    P_Load.plot( y = ['Load Profile', 'Peak Shaved Load Profile'], style=["-","-" ] , ylabel = 'P [kW]', grid =True,figsize=(3.5, 2))
    plt.legend(loc='best')
    #title= 'Load Profile',

    #Plotting the revenue
    Date_Start_Rev = Year_Month[0] + '-' + Year_Month[1] +'-01'
    Rev_Colums = np.column_stack((Rev_FCR,Rev_Energy))
    Days = pd.date_range(start = Date_Start_Rev, freq= "D",name='Dates', periods = Days).strftime('%Y-%m-%d')
    Rev_DF = pd.DataFrame(data=Rev_Colums, columns= ["FCR","Energy"], index=Days)
    #title = "Estimated Daily Revenue"
    Rev_DF.plot(y = ["FCR","Energy"], kind ='bar', ylabel = "Daily Revenue [Euros]", grid=True,figsize=(3.5, 2))
    plt.legend(loc="best")    

    return


def BESS_Iterator(BESS_Array, Charge_Array, Discharge_Array, Initial_BESS,
Frequency_Data, FCR_Bid_Price, FCR_Price, Load_Profile, El_Price, Grid_Cap, 
Peak_Cost):
    #Iterating over the permissable BESS_Sizes

    #Initiating my variables
    Curr_BESS = Initial_BESS; Optimal_BESS = Initial_BESS
    #Finding the number of elements of the array where Num_Elements[1] = number of elements
    Num_Elements = len(BESS_Array); 
    Lower_Bound = 0; Upper_bound = Num_Elements -1 #Upper and lower bound of the algorithm
    #Where the initial battery size is within the list 
    Initial_Index = np.where(BESS_Array == Initial_BESS)[0][0] #This returns a tuple (index,datatype)
    #Setting the first iteration as the current index
    Curr_Index = Initial_Index; Prev_Index = Initial_Index
    #The revenue of the most optimal BESS size
    Highest_Net_Rev = np.zeros(4); Curr_Net_Rev = np.zeros(4); Prev_Net_Rev = np.zeros(4)
    #Stop conditions to see if the programme has tested with higher or lower than the inital value
    Tested_Larger = False; Tested_Smaller = False

    #Wants to keep track of the number of cycles as well
    Curr_N_Cycles = 0; N_Cycles_High_Rev = 0 
    #Want also track the amount that the system cost to compare between the alternatives
    Curr_Cost = 0; Prev_Cost = 0; Highest_Rev_Cost = 0

    #print(BESS_Array);print(Discharge_Array); print(Charge_Array)
    while True:
        #While loop iterating over the permissable battery configurations
        Curr_BESS = BESS_Array[Curr_Index]
        Curr_Discharge = Discharge_Array[Curr_Index]
        Curr_Charge = Charge_Array[Curr_Index] 
        #Calculating the Cost of the choosen BESS
        Curr_Cost = BESS_Installment_Cost(Curr_BESS)

        #Prev cost and BESS size 
        Prev_BESS = BESS_Array[Prev_Index]
        Prev_Cost = BESS_Installment_Cost(Prev_BESS)


        #Printing a message for the user
        MSG = "Processing battery size: " + str(Curr_BESS) + " kWh"
        print(MSG)

        #Solving the optimization problem here
        Curr_Net_Rev, Curr_N_Cycles = BESS_Solver(BESS_Size = Curr_BESS, Load_Profile = Load_Profile, 
        FCR_Bid_Price = FCR_Bid_Price, FCR_Price = FCR_Price, Freq_Data = Frequency_Data, 
        BESS_Cost = Curr_Cost, El_price= El_Price, Grid_Cap = Grid_Cap, P_C_Max = Curr_Charge,
        P_D_Max = Curr_Discharge, Peak_Cost = Peak_Cost)

        #We need to include the battery cost some how as well se if the increased cost is justified
        #This may be done through using a relative cost i.e Curr_Cost/Prev_Cost*Curr_Rev > Prev_Rev

        #Stop conditions to deem if the algorithm has reached a local optimal solution
        if Curr_Index != Initial_Index:
            #Checking if the algorithm has atleast went through one iteration
            if Curr_Net_Rev[0] >= Prev_Net_Rev[0]*Curr_Cost/Prev_Cost:
                #If the current net revenue is higher than the last 
                if Curr_Net_Rev[0] > Highest_Net_Rev[0]*Curr_Cost/Highest_Rev_Cost:
                    #Checking if a new optimal solution has been found and update the Optimal BESS config
                    Optimal_BESS = Curr_BESS 
                    Highest_Net_Rev = Curr_Net_Rev 
                    N_Cycles_High_Rev = Curr_N_Cycles
                    Highest_Rev_Cost = Curr_Cost

            if not (Curr_Net_Rev[0] >= Prev_Net_Rev[0]*Curr_Cost/Prev_Cost) or Curr_Index == Upper_bound or Curr_Index == Lower_Bound:
                #If it's not more profitable
                #Checking if the expected annual income has decreased in comparision with the previous case.
                if Curr_Index > Initial_Index and Initial_Index != Lower_Bound and Tested_Smaller == False:
                    #Checking if the algorithm has tried the lower values of index
                    Prev_Net_Rev = Initial_Net_Rev #Updating the variables 
                    Tested_Larger = True
                    Curr_Index = Initial_Index - 1
                    Prev_Index = Initial_Index

                    continue
                elif Curr_Index < Initial_Index and Initial_Index != Upper_bound and Tested_Larger == False:
                    #Checking if the algorithm have checked the larger values 
                    Prev_Net_Rev = Initial_Net_Rev 
                    Curr_Index = Initial_Index + 1
                    Tested_Smaller = True
                    Prev_Index = Initial_Index
                    
                    continue
                else: 
                    #If all options have been exhausted break the loop
                    break
            
        #Iterations
        Prev_Net_Rev = Curr_Net_Rev
        Prev_Index = Curr_Index

        if Curr_Index > Initial_Index and Curr_Index != Upper_bound:
            #If we have looked to the right of the BESS array and if the algorithm can proceed with and 
            #new battery size
            Curr_Index += 1
        elif Curr_Index < Initial_Index and Curr_Index != Lower_Bound:
            #Checking if the algorithm is looking to the left of the initial battery size
            Curr_Index -= 1
        elif Curr_Index == Initial_Index:
            #If we're on our initial iteration and there's room for either looking to 
            #the right or left of the array
            if Initial_Index == Upper_bound:
                #Only option is to look to the left
                Curr_Index -= 1 
            else:
                #Always start with an increasing battery size
                Curr_Index +=1

            Initial_Net_Rev = Curr_Net_Rev #Insert expected income here from the initial case

            #setting the inital BESS as the most optimal
            Optimal_BESS = Curr_BESS 
            Highest_Net_Rev = Curr_Net_Rev 
            N_Cycles_High_Rev = Curr_N_Cycles
            Highest_Rev_Cost = Curr_Cost

            if Upper_bound == Lower_Bound:
                #Only one iteration is possible 
                #Have to add the revenue and costs 
                break #Optimal choice isn't that hard to define then :/
        print("Optimal BESS and Curr_Net_Rev")
        print(Optimal_BESS)
        print(Curr_Net_Rev)

    print("Optimal solution has been found.")
    return Optimal_BESS, Highest_Net_Rev, N_Cycles_High_Rev, Highest_Rev_Cost 

def BESS_Solver(BESS_Size, Load_Profile, FCR_Bid_Price, FCR_Price, Freq_Data, BESS_Cost, 
El_price, Grid_Cap, P_C_Max, P_D_Max, Peak_Cost):
    #Instance in the programme that selects the relevant information that should be sent to the 
    #Optimization algorithm. Have to find the initial month of the 

    SoC_0 = 1 #Initial state of charge 
    Est_Rev = 0 #Estimated revenue for the period
    N_Cycles = 0 #Number of cycles that has passed through the BESS
    SoC_Array = np.empty(0)
    P_Energy_Array = np.empty(0)
    P_FCR_N_Bids_Array = np.empty(0)
    P_FCR_D_Bids_Array = np.empty(0)
    Load_Array = np.empty(0)

    #Saving the Revenues
    Rev_Energy = np.empty(0)
    Rev_Peak = np.empty(0)
    Rev_FCR = np.empty(0)
    
    #Saving the the amound of revenue of each type of revenue stream
    Total_Peak_Rev = 0
    Total_Energy_Rev = 0
    Total_FCR_Rev = 0

    #Want to iterate over each day that we're reeding from the frequency data

    #Number of frequency samples
    N_Frequency_Samp = Freq_Data.shape[0] #Number of rows == number of days that we want to analyse
    #Number of Samples per day
    N_Samp_Day = int(24*60/15) #Have to change this if the time step changes

    #Previous day, used to check if we have switched months
    Prev_Day = str(Freq_Data.index[0].year) +'-'+ str(Freq_Data.index[0].month) + '-' + str(Freq_Data.index[0].day)

    Prev_Peak = 0 
    Max_Load = 0

    for a in range(0,N_Frequency_Samp, N_Samp_Day):#Looping over the amount of days
        #Current day that we're executing
        Curr_Day = str(Freq_Data.index[a].year) + '-' + str(Freq_Data.index[a].month) + '-' + str(Freq_Data.index[a].day)
        print(Curr_Day)
        
        Data_Index = Curr_Day #The day of data that we're reeding 
        Curr_Year_Month = Curr_Day.split("-")
        Prev_Year_Month = Prev_Day.split("-")

        if Curr_Year_Month[0] != Prev_Year_Month[0] or Curr_Year_Month[1] != Prev_Year_Month[1]: #Checking the first 6 elements of the string
            #We're on a different year or month
            #Updating the SoC_0
            if Curr_Year_Month[0] != Prev_Year_Month[0] or int(Curr_Year_Month[1]) != int(Prev_Year_Month[1]) + 1:
                SoC_0 = 1 #May change this

            #Updating the revenues
            Total_Peak_Rev += Rev_Peak 
            Total_Energy_Rev += np.sum(Rev_Energy) 
            Total_FCR_Rev += np.sum(Rev_FCR) 
            
            #Maxium load of the month and max peak
            MSG = "Max Load and Peak of the Month "+ Prev_Year_Month[0] +"-"+ Prev_Year_Month[1] +": %.1f , %.1f kW" % (Max_Load, Prev_Peak)
            print(MSG)
            
            #Want to illustrate the data for the previous month using the data illustrator fun
            
            #Data_Illustrator(SoC_Array,P_FCR_N_Bids_Array,P_FCR_D_Bids_Array,P_Energy_Array,\
            #Load_Array,Rev_FCR,Rev_Energy,Prev_Day)
            #Re-initialize the arrays where I save the energy and revenues
            SoC_Array = np.empty(0)
            P_Energy_Array = np.empty(0)
            P_FCR_N_Bids_Array = np.empty(0)
            P_FCR_D_Bids_Array = np.empty(0)
            Load_Array = np.empty(0)

            #Saving the Revenues
            Rev_Energy = np.empty(0)
            Rev_Peak = np.empty(0)
            Rev_FCR = np.empty(0)
            #Resetting the stored value for the peak aswell
            Prev_Peak = 0  
            Max_Load = 0
            #Begin a new instance of iterations

        #Extracting relevant data that will be sent to the solver
        Monthly_Freq_Data = Freq_Data.loc[Data_Index].to_numpy(dtype = np.float64)
        Monthly_FCR_Data = FCR_Price.loc[Data_Index].to_numpy( dtype = np.float64)

        Monthly_FCR_Bid_Data = FCR_Bid_Price.loc[Data_Index].to_numpy(dtype = np.float64)
        Monthly_Load_Profile = Load_Profile.loc[Data_Index].to_numpy(dtype = np.float64) 
        
        Load_Array = np.append(Load_Array, Monthly_Load_Profile[:,0]) #Storing the load values

        #Calculating the maximum load 
        Max_Load = np.amax(Load_Array)

        #Number of samples frequency and hours
        N_Samples = len(Monthly_Freq_Data)
        N_Hours = len(Monthly_FCR_Bid_Data)
        N_Samples_Hour = int(N_Samples/N_Hours)

        if isinstance(El_price,pd.DataFrame):
            #Use a spot price
            Monthly_El_Price = El_price.loc[Data_Index].to_numpy()
            #Want to have a good guess for when the Battery should sell and when it should 
            #not sell
        else:
            Monthly_El_Price = El_price #Fixed electricity price might be useful
            
        #Defining my optimization problem
        #Initiating the model
        Msg = "Initiating the optimization model..."
        print(Msg)

        #Change d_t if step size is changed
        Solver = Charge_Controller(Freq_Data= Monthly_Freq_Data, 
        FCR_Price=Monthly_FCR_Data, FCR_Bid_Price=Monthly_FCR_Bid_Data, SoC_0 = SoC_0, P_D_Max= P_D_Max, P_C_Max= P_C_Max, 
        BESS_Cost= BESS_Cost, Load_Curve= Monthly_Load_Profile,P_Cap= Grid_Cap, Cap_BESS = BESS_Size, d_t= 15/60, 
        Cost_Peak=Peak_Cost, El_Price= Monthly_El_Price, Prev_Peak= Prev_Peak, Max_Load = Max_Load)

        print("Defining the constriants")
        #Defining the bounds 
        lb_Bounds,ub_Bounds = Solver.Set_Bounds()
        Var_Bounds = Bounds(lb_Bounds,ub_Bounds)
        

        #Defining the linear constraints
        A_Lin_Const, lb, ub = Solver.Set_Linear_Const()
        Lin_Const = LinearConstraint(A_Lin_Const,lb,ub) 

        #Defining the non-linear constraints and bounds 
        ub = np.zeros(N_Hours)
        lb = np.full(N_Hours,np.NINF)
        
        n = N_Hours*2 +1 +N_Samples*4 + 1
        #Defining the hessian to be zero
        hessian = lambda x, v: np.zeros((n,n)) #Defining a zero hessian due to that the second derrivatives are zero
        Non_Lin_Bid = NonlinearConstraint(Solver.FCR_N_Bidding_Const,lb,ub,jac = "2-point", hess = hessian)

        lb = 0
        #Non-linear constraint to ensure that we're tracking the number of cycles
        Non_Lin_Cycle = NonlinearConstraint(Solver.BESS_Throughput,lb,lb,jac='2-point',hess = hessian)

        #To give some wiggle room
        lb = np.full(N_Samples,-0.1)
        ub = np.full(N_Samples,0.1)
        #Non-linear constraint to ensure that the bids and P_energy is not active at the same time
        Non_Lin_Bid_Product = NonlinearConstraint(Solver.Bidding_Const,lb,ub, jac= Solver.Bidding_Const_Jac,hess=Solver.Bidding_Const_Hess)
    
        x_0_soc = np.full(N_Samples+1, SoC_0)  # np.random.rand(N_Samples+1)

        #Bidding guesses for FCR_N and FCR_D
        
        #Want to impose a number of conditions to our initial guess
        #I.e we may only have 3 bids in a row

        #Bid_Guess = np.full(N_Hours,np.amin([0.5*BESS_Size[0],Grid_Cap]))*0
        #If we want to make a guess on the optimal energy purchase or selling. 
        #Energy_Guess = np.full(N_Samples,0)

        #Intial guess for bids, power and SoC. Seems it's beest to keep it to SoC == SoC_0 and rest is zero
        x_0 = np.concatenate((x_0_soc,np.zeros(3*N_Samples + 2*N_Hours+1,dtype= np.float64)))
        
        #Printing day of execution
        Msg = "Solving the optimization problem for day " + Data_Index +"..."
        print(Msg)


        #Step size, you may tune this later
        #Steps_SoC = np.full(N_Samples+1, 10e-4)
        #Steps_Bids = np.full(N_Hours, 0.1)
        #Steps_Energy = np.full(N_Samples,0.1)
        #Steps_FCR_Power = np.full(N_Samples,10e-3)
        #Steps_Cycles = np.array([10e-4])

        #Steps_Size = np.concatenate((Steps_SoC,Steps_Bids,Steps_FCR_Power,Steps_Bids,Steps_FCR_Power,Steps_Energy,Steps_Cycles))


        hessian_obj = lambda x: np.zeros((n,n))
        #Using the Trust-Constrained method implemented in Scipy #BFGS('exception_strategy' = 'damp_update')
        Result = minimize(Solver.Objective_Function, 
        x_0, method = 'trust-constr', jac='3-point', hess = hessian_obj, bounds= Var_Bounds, 
        constraints = [Lin_Const,Non_Lin_Bid,Non_Lin_Cycle,Non_Lin_Bid_Product], options= {'verbose':1,'disp':True,'sparse_jacobian': True,
        'gtol':10e-6,
        'xtol': 10e-4,
        'barrier_tol':10e-6,
        'maxiter' : 100000})
        
        
        #Result is an dictionary containing the resulting variables and the function value
        if Result.get('success') == True:

            x = Result.get('x')

            #Updating the current peak of the month and calculating the revenue
            Prev_Peak, Prev_Rev_Peak,\
                Prev_Rev_FCR, Prev_Rev_Energy = Rev_Estimation(x,N_Hours,N_Samples,N_Samples_Hour,Monthly_El_Price,
            Monthly_FCR_Bid_Data,Monthly_FCR_Data, Monthly_Load_Profile, Peak_Cost, Prev_Peak, Max_Load)
            N_Cycles += x[-1]
            SoC_0 = x[N_Samples] #Updating the SoC
            
            #Updating the revenue streams
            Rev_Energy = np.append(Rev_Energy,[Prev_Rev_Energy], axis=0)

            #Want to only store the values of the peak that is relevant to the solution
            
            #Updating the peak rev has increased
            Rev_Peak = Prev_Rev_Peak

            
            
            Rev_FCR = np.append(Rev_FCR,[Prev_Rev_FCR], axis= 0)
            #print("Current highest peak"); print(Prev_Peak)
            #print("Curent peak and energy revenue."); print(np.column_stack([Rev_Peak,Rev_Energy]))
            #Used to ensure that the peak doesn't get counted twice
            
            #Plotting the result
            Index_P_FCR_N_Bids = N_Samples +1
            Index_P_FCR_D_Bids = N_Samples*2 + N_Hours +1
            Index_P_Energy = N_Samples*3 +1 + N_Hours*2
            
            #Saving the data
            SoC_Array = np.concatenate((SoC_Array,x[0:N_Samples]))
            P_Energy_Array = np.concatenate((P_Energy_Array,x[Index_P_Energy:Index_P_Energy+N_Samples]))
            P_FCR_D_Bids_Array = np.concatenate((P_FCR_D_Bids_Array,x[Index_P_FCR_D_Bids:Index_P_FCR_D_Bids+N_Hours]))
            P_FCR_N_Bids_Array = np.concatenate((P_FCR_N_Bids_Array,x[Index_P_FCR_N_Bids:Index_P_FCR_N_Bids+N_Hours]))

        else:
            Msg = "No solution was found for " + Data_Index + "." 
            print(Msg)
        #Updating the previous day to become the current day

        Prev_Day = Curr_Day

    #Maxium load of the month and max peak
    MSG = "Max Load and Peak of the Month "+ Curr_Year_Month[0] +"-"+ Curr_Year_Month[1] +": %.1f , %.1f kW" % (Max_Load, Prev_Peak)
    print(MSG)
    
    #Plotting the final month
    #Data_Illustrator(SoC_Array,P_FCR_N_Bids_Array,P_FCR_D_Bids_Array,P_Energy_Array,\
    #Load_Array,Rev_FCR,Rev_Energy,Prev_Day)
    
    Total_Peak_Rev += Rev_Peak 
    Total_Energy_Rev += np.sum(Rev_Energy) 
    Total_FCR_Rev += np.sum(Rev_FCR) 
    #Adding the Peak shaving revenue to the estimated revenue
    Est_Rev += Total_Peak_Rev + Total_Energy_Rev + Total_FCR_Rev 
    
    #Printing the revenues
    print("Final Revenues: [Total, Peak, FCR, Energy Arbitrage, Number of Cycles]")
    print([Est_Rev,Total_Peak_Rev,Total_FCR_Rev,Total_Energy_Rev, N_Cycles])

    #plt.show()
    #Returns the estimated as a list
    return np.array([Est_Rev,Total_Peak_Rev,Total_FCR_Rev,Total_Energy_Rev]), N_Cycles
    
def Rev_Estimation(x,N_Hours, N_Samples, N_Samples_Hour,El_Price,FCR_Bid_Data,FCR_Data,Load_Profile,Cost_Peak,Prev_Peak,Max_Load):
    #Function used to estimate the revenue of the solution by also taking that we won't get
    #all the bids that we make into account

    #Calculating the saving made by the peak shaving 
    Index = N_Samples*3 + 1 + N_Hours*2
    Peak_Vector = np.empty(N_Samples)
    
    for a in range(N_Hours):
        Minutes = a*N_Samples_Hour
        Peak_Vector[a] = Load_Profile[a,0] + np.mean(x[Index + Minutes: Index + Minutes + N_Samples_Hour])
    #Calculating the peak cost or revenue    
    
    if np.round(Prev_Peak,decimals=0) < np.round(np.amax(Peak_Vector),decimals=0):
        #Adding this cost only if it's contributing to the montly peak cost
        Prev_Peak_Return = np.round(np.amax(Peak_Vector),decimals=0)
        Rev_Peak = (Max_Load - np.amax(Peak_Vector))*Cost_Peak
    else:
        Prev_Peak_Return = Prev_Peak
        Rev_Peak = (Max_Load - Prev_Peak)*Cost_Peak
    
    #Calculating the battery usage cost:

    FCR_Bid_Price_N = FCR_Bid_Data[:,0]
    FCR_Bid_Price_D = FCR_Bid_Data[:,1]

    #Calculating the FCR revenue
    Index_FCR_N = 2*N_Samples
    Index_FCR_D = 2*N_Samples + N_Hours
    Rev_FCR_Bid = (np.dot(FCR_Bid_Price_N, x[Index_FCR_N: Index_FCR_N + N_Hours]) \
        + np.dot(FCR_Bid_Price_D, x[Index_FCR_D:Index_FCR_D + N_Hours]))/1000
    
    #Estimating the revenue of the sold energy
    #Prices:
    FCR_Price_N_Upp = FCR_Data[:,0]
    FCR_Price_N_Down = FCR_Data[:,1]

    #Now it's important to distinguish between when the BESS is opperating in FCR_N_Upp and FCR_N_Down
    One_quater = int(N_Samples_Hour/4)
    Rev_FCR_En = 0
    for a in range(N_Hours):
        #Identify when P_FCR_N is negative or postive each 15 min which means that I have to divide by 4 and
        #convert the energy price to EUR/MWh
        Index = a*N_Samples_Hour + N_Samples + 1 + N_Hours

        #Calculating the revenue
        First_15 = np.mean(x[Index:Index + One_quater])
        if First_15 < 0:
                Rev_FCR_En += np.abs(First_15)*FCR_Price_N_Upp[a]/4 #In EUR/MWh
                
        elif First_15 >= 0:
                Rev_FCR_En += First_15*FCR_Price_N_Down[a]
        Seccond_15 = np.mean(x[Index + One_quater: Index + One_quater*2])
        
        if Seccond_15 < 0:
                Rev_FCR_En += np.abs(Seccond_15)*FCR_Price_N_Upp[a]
        elif Seccond_15 >= 0:
                Rev_FCR_En += Seccond_15*FCR_Price_N_Down[a]
        Third_15 = np.mean(x[Index + One_quater*2: Index +One_quater*3])
        
        if Third_15 < 0:
                Rev_FCR_En += np.abs(Third_15)*FCR_Price_N_Upp[a]
        elif Third_15 >= 0:
                Rev_FCR_En += Third_15*FCR_Price_N_Down[a]
        Last_15 = np.mean(x[Index + One_quater*3:Index + N_Samples_Hour]) 
        if Last_15 < 0:
                Rev_FCR_En += np.abs(Last_15)*FCR_Price_N_Upp[a]
        elif Last_15 >= 0:
                Rev_FCR_En += Last_15*FCR_Price_N_Down[a]

    FCR_Rev_Factor = 0.8 #Factor to determine a more realistic bid revenue

    #Estimating the Energy revenue
    Rev_Energy = 0 #Initiating the varaible 
    Index = N_Samples*3 + 1 + N_Hours*2
    if isinstance(El_Price,float):
        #Meaning that we have a fixed price for the electricity
        Rev_Energy =  El_Price*np.sum(x[Index:Index+N_Samples])/4
    else: #Know that the spotprices are 
        Iteration_Energy_Price = 0
        for a in range(N_Samples):
            #Calculating the cost using the spot given each hour. 
            Rev_Energy +=  x[Index + a]*El_Price[Iteration_Energy_Price,0]/4
            if (a + 1) % N_Samples_Hour == 0: #Checking when an hour has passed
                    Iteration_Energy_Price += 1 #Take one more step
        Rev_Energy = Rev_Energy/1000

    #Estimated revenue
    return Prev_Peak_Return, Rev_Peak, (Rev_FCR_Bid + Rev_FCR_En/4000)*FCR_Rev_Factor, -Rev_Energy

def BESS_Installment_Cost(BESS_Size):
    #Calculting the cost of the Associated BESS-size
    Cost_per_kWh = 850 #euro/kWh

    BESS_Cost = BESS_Size*Cost_per_kWh

    return BESS_Cost 


def BESS_Vector(BESS_Size_Max,BESS_Size_Min):
    #generating a array of permissable BESS sizes and capacities
    Permissable_BESS_Size = 76.8 #kWh
    #Maximum charge
    Max_Charge = 60 #kW
    #Maximum discharge
    Max_Discharge = 75 #kW
    #Number of multiples of the smallest permissable size
    Min_Multiple = round(int(BESS_Size_Min/Permissable_BESS_Size))
    Max_Multiple = round(int(BESS_Size_Max/Permissable_BESS_Size))

    #Creating the array containing the permissable BESS-sizes
    num_Samples = Max_Multiple - Min_Multiple +1
    BESS_Array = np.linspace(BESS_Size_Min,BESS_Size_Max, num= num_Samples,endpoint=True)
       
    #Creating the array containing the associated max charge of each step in BESS size
    Charge_Array = np.linspace(Max_Charge*Min_Multiple,Max_Charge*Max_Multiple,num=num_Samples,endpoint=True)
    #Creating the array containing the associated min charge of each step in BESS size
    Discharge_Array = np.linspace(Min_Multiple*Max_Discharge, Max_Multiple*Max_Discharge,num=num_Samples,endpoint=True)

    return np.round(BESS_Array,decimals=1), np.round(Charge_Array,decimals =1), np.round(Discharge_Array,decimals=1)
    

def User_input():
    #Calling and handeling user input to be used in the optimization algorithm
    print("Please input the required data to perform the analysis. \n")
    Choice_BESS = False; Choice_El_Price = False; Choice_Peak = False
    while True:
        Selector_Indication(Choice_BESS, Choice_El_Price,Choice_Peak)
        Choice = input("Choose the data that should be feed in BESS size, Electricity Price, Peak cost or Terminate: \nBESS/El/Peak/Terminate ")
        if Choice.lower() == "bess":
            Choice_BESS = True
            BESS_Size_Max, BESS_Size_Min, BESS_Initial_Size = BESS_selector()
        elif Choice.lower() == "el":
            Choice_El_Price = True
            El_Price, Choice_Energy_Reg = Electricity_Price_Sel()
        elif Choice.lower() == "terminate":
            raise  User_termination("User terminated the programme.")
        elif Choice.lower() == "peak":
            Choice_Peak = True
            Msg = "Choose an appropriate power peak cost of the plant expressed in [EUR/kW]: "
            Peak_Cost = Numeric_Val_Selector(Msg)


        if Choice_BESS == True and Choice_El_Price == True and Choice_Peak == True:
            #If all the required data has been inserted
            while True:
                Choice = input("Run Simulation or change parameters. Run/No/Param: ")

                if Choice.lower() == "run":
                    print('Running the simulation.')
                    break
                elif Choice.lower() == "no":
                    #Terminating the simulationg
                    raise User_termination("User terminated the simulation")
                elif Choice.lower() == "param":
                    break
            if Choice.lower() == "param":
                #Pass the break
                continue
            break
        
        
    return BESS_Size_Max, BESS_Size_Min, BESS_Initial_Size, \
        El_Price, Choice_Energy_Reg, Peak_Cost


def Selector_Indication(Choice_BESS, Choice_El, Choice_Peak, ):
    #Prints an indication to which variables have been defined
    Msg_BESS = "False"; Msg_El = "False"; Msg_Peak = "False"
    if Choice_BESS == True:
        Msg_BESS = "True"
    if Choice_El == True:
         Msg_El = "True"
    if Choice_Peak == True:
        Msg_Peak = "True"
    Msg = "Already defined input:\nBESS: " + Msg_BESS + "\nElectricity price: " + Msg_El + "\nPeak price: " + Msg_Peak 
    print(Msg)
    return
    
def Numeric_Val_Selector(Msg):
    #Choosing the maximum grid capacity in [kwh]
    while True:
        try:
            Numeric_Param = input(Msg)
            Numeric_Param = float(Numeric_Param)
        except ValueError:
            print("Please insert a numeric value into the terminal.")
            continue
        break
        
    return Numeric_Param


def Electricity_Price_Sel():
    #Defining the electricity price that will be used by the solver
    while True:
        Choice = input("Define the type of electricity price that you wish to use in the analysis, i.e Spot Price or Fixed: Spot/Fixed ")
        if Choice.lower() == "spot":
            print("Ensure that the spot price data have been inserted in the folder -> Prices and Revenue/Spot Price")
            folder_name = "Prices and Revenue"
            El_Price = Data_Import.Spot_Price_Reader(folder_name)
            break
        elif Choice.lower() == "fixed":
            while True:
                try:
                    El_Price = input("Choose an appropriate value for the fixed energy price in [EUR/kWh]: ")
                    El_Price = float(El_Price)
                except ValueError:
                    print("Please insert a number.")
                    continue
                break
            break
    
    while True:
        Msg = "Input the energy region that you want to make the analysis on SE1/SE2/SE3/SE4: "
        Choice_Energy = input(Msg)
        #Dropping the other data
        if Choice_Energy.lower() == "se1":
            if isinstance(El_Price, pd.DataFrame): #Checking if it's a dataframe
                El_Price = El_Price.drop(columns = ['SE2','SE3','SE4'])
            break
        elif Choice_Energy.lower() == "se2":
            if isinstance(El_Price, pd.DataFrame):
                El_Price = El_Price.drop(columns = ['SE1','SE3','SE4'])
            break
        elif Choice_Energy.lower() == "se3":
            if isinstance(El_Price, pd.DataFrame):
                El_Price = El_Price.drop(columns = ['SE1','SE2','SE4'])
            break
        elif Choice_Energy.lower() == "se4":
            if isinstance(El_Price, pd.DataFrame):
                El_Price = El_Price.drop(columns = ['SE1','SE2','SE3'])
            break
    
    return El_Price, Choice_Energy

def BESS_selector():
    
    #Define the BESS sizes that we will 
    Initial_BESS_size = Inital_BESS_Size_Choice()

    print("Choose a maximum and optionally a minimum battery size.")
    Input_Msg = "Choose a maximum battery size that is a multiple of 76.8 [kWh] and is larger than the inital battery size: "
    while True:
        Max_Bat_Size = Bat_Size_Rounder(Input_Msg,"max sizing")
        if Max_Bat_Size >= Initial_BESS_size:
            break


    while True:
        #User makes a choice
        Choice = input("Do you want to define a minimum battery size: Yes/No. \nIf not the minimum choice of battery size will be choosen to be the same as the initalel battery size.\nAnswer: ")
        
        if Choice.lower() == 'yes':
            #Letting the user define a minimum battery size
            while True:
                Input_Msg = "Choose a minimum battery size that is a multiple of 76.8 [kWh]: "
                Min_Bat_Size = Bat_Size_Rounder(Input_Msg,"min sizing")
                if Min_Bat_Size <= Max_Bat_Size and Max_Bat_Size >= Initial_BESS_size:
                    #Checking if the minimum size if smaller then the maximum size
                    break
                elif Min_Bat_Size > Max_Bat_Size and Max_Bat_Size >= Initial_BESS_size:
                    print("Please choose maximum size that is larger or equal to the minimum size.")
                elif Min_Bat_Size <= Max_Bat_Size and Max_Bat_Size < Initial_BESS_size:
                    print("Please choose a maximum size that is larger or equal the inital size.")
                elif Min_Bat_Size > Max_Bat_Size and Max_Bat_Size < Initial_BESS_size:
                    print("Please choose a maxiumum size that is larger than the inital and minimum size.")

        elif Choice.lower() == 'no':
            Msg = "The user didn't specify a minimum battery size, min bess size has been set to %.1f [kWh]." %Initial_BESS_size
            print(Msg)
            #Defining the minumum battery size
            while True:
                Min_Bat_Size = Initial_BESS_size
                if Min_Bat_Size <= Initial_BESS_size:
                    #Have to choose a bound that is lower than the Initial size
                    break
                else:
                    print("Please input a lower bound that is smaller or equal to the initial battery size.")
        if Choice.lower() == 'no' or Choice.lower() == 'yes':
            break
    return Max_Bat_Size, Min_Bat_Size, Initial_BESS_size

def Inital_BESS_Size_Choice():
    #Here will the user feed in the nessary information for the BESS
    Input_Msg = "Choose and initial battery that is an multiple of 76.8 [kWh]: "
    Inital_BESS_Size = Bat_Size_Rounder(Input_Msg,'initial sizing')
        
    return Inital_BESS_Size


def Bat_Size_Rounder(Input_Msg,Instance):
    #Function responsible for checking and rounding the battery size to a permissable size
    #Mainly defined to avoid repeating code
    New_it = False
    
    while True:
        try:
            Bat_choice = input(Input_Msg)
            Bat_choice = float(Bat_choice)
        except ValueError:
            try:
                Bat_choice = int(Bat_choice)
            except ValueError:
                #Error handling
                print("Please insert a number.")
                pass
        Permissable_BESS_Size = float(76.8) 
        if Bat_choice % Permissable_BESS_Size != 0:
                #If not multiple of an available BESS size, round to nearest multiple
                Bat_choice = np.round(Permissable_BESS_Size*round(Bat_choice/Permissable_BESS_Size),decimals=1)
                Msg = "Choosen battery size has been rounded to %.1f [kWh]." %Bat_choice
                print(Msg)
                while True:
                    Answer = input("Do you wish to proceed? Yes/No: ")
                    if Answer.lower() == 'yes':
                        New_it = False
                        break
                    elif Answer.lower() == 'no':
                        while True:
                            Answer = input("Do you wish to change the "+ Instance + "? Yes/No: ")
                            if Answer.lower() == 'no':
                                #Raises an error can fix this later through defining a custom defined error
                                raise  User_termination("User terminated the programme.")
                            elif Answer.lower() == 'yes':
                                #Choose a new iteration
                                New_it = True
                                break
                    if Answer.lower() == 'no' or Answer.lower() == 'yes':    
                        break
        if New_it == False:
            #Determine if the loop should break
            break
    return Bat_choice

#Setting the current directory to the one that the script is in
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)
os.chdir(dname)

#Options
"""
params = {'font.size' : 10,
          'font.family' : 'serif',
          }
plt.rcParams.update(params) 
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
"""

main()
